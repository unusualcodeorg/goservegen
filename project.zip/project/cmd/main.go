package main

import "github.com/yourusername/project/startup"

func main() {
	startup.Server()
}
